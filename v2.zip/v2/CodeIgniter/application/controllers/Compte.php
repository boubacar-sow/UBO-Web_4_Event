<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Compte extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('db_model');
        $this->load->helper('url_helper');
    }

    public function creer()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('id', 'id', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/menu_login');
            $this->load->view('compte_creer');
            $this->load->view('templates/bas');
        } else {
            if($this->db_model->set_compte()) {
                $this->load->view('templates/menu_login');
                $this->load->view('compte_succes');
                $this->load->view('templates/bas');
            }
        }
    }

    public function connecter()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('pseudo', 'pseudo', 'required');
        $this->form_validation->set_rules('mdp', 'mdp', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/menu_login');
            $this->load->view('compte_connecter');
            $this->load->view('templates/bas');
        } else {
            $username = addslashes($this->input->post('pseudo'));
            $password = $this->input->post('mdp');
            $salt = "monsel";
            $mdp = hash('sha256', $salt.$password);
            if ($this->db_model->connect_compte($username, $mdp)) {
                $statut = $this->db_model->get_user_status($username);
                $session_data = array('username' => $username, 'statut' => $statut);
                $this->session->set_userdata($session_data);
                if ($statut->cpt_statut == 'I') {
                    redirect('compte/accueil_invite', 'refresh');
                } else if ($statut->cpt_statut == 'O') {
                    redirect('compte/accueil_admin', 'refresh');
                }
            } else {
                $this->load->view('templates/menu_login');
                $this->load->view('page_erreur_identifants');
                $this->load->view('templates/bas');
            }
        }
    }

    public function accueil_admin()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['admin'] = $this->db_model->get_admin_info($username);
        if ($statut->cpt_statut == 'O') {
            $this->load->view('templates/menu_administrateur');
            $this->load->view('page_accueil_admin', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function accueil_invite()
    {

        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['inv'] = $this->db_model->get_invite_info($username);
        if ($statut->cpt_statut == 'I') {
            $this->load->view('templates/menu_back_invite');
            $this->load->view('page_accueil_invite', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function deconnecter()
    {
        $this->session->unset_userdata('username');
        $this->session->sess_destroy();
        redirect('accueil/afficher', 'refresh');
    }

    public function afficher_profil()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['inv'] = $this->db_model->get_invite_info($username);
        if ($statut->cpt_statut == 'I') {
            $this->load->view('templates/menu_back_invite');
            $this->load->view('page_profil_invite', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function afficher_profil_admin()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['admin'] = $this->db_model->get_admin_info($username);
        if ($statut->cpt_statut == 'O') {
            $this->load->view('templates/menu_administrateur');
            $this->load->view('page_profil_admin', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function changer_mdp_invite()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
	if ($statut->cpt_statut == 'I') {
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('mdp_actu', 'mdp_nouv', 'required');
        $this->form_validation->set_rules('mdp_actu', 'mdp_nouv', 'required');
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/menu_back_invite');
            $this->load->view('page_compte_invite');
            $this->load->view('templates/bas');
        } else {
            $mdp_actuel = $this->input->post('mdp_actu');
            $mdp_nouveau = $this->input->post('mdp_nouv');
            $mdp_confirm = $this->input->post('conf_mdp');
            $salt = "monsel";
            $mdp_actuel = hash('sha256', $salt.$mdp_actuel);
            $mdp_nouveau = hash('sha256', $salt.$mdp_nouveau);
            $mdp_confirm = hash('sha256', $salt.$mdp_confirm);
            if ($this->db_model->connect_compte($username, $mdp_actuel)) {
                if(strcmp($mdp_nouveau, $mdp_confirm) == 0){
                    $this->db_model->change_mdp($mdp_actuel, $mdp_nouveau);
                    $this->load->view('templates/menu_back_invite');
                    $this->load->view('compte_changer_mdp');
                    $this->load->view('templates/bas');
                }else {
                    $this->load->view('templates/menu_back_invite');
                    $this->load->view('page_erreur_changer_mdp_invite');
                    $this->load->view('templates/bas');
                }
            } else {
                $this->load->view('templates/menu_back_invite');
                $this->load->view('page_erreur_changer_mdp_invite');
                $this->load->view('templates/bas');
            }
        }
}else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function changer_mdp_admin()
    {

        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
if ($statut->cpt_statut == 'O') {
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('mdp_actu', 'mdp_nouv', 'required');
        $this->form_validation->set_rules('mdp_actu', 'mdp_nouv', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/menu_administrateur');
            $this->load->view('page_compte_admin');
            $this->load->view('templates/bas');
        } else {
            $mdp_actuel = $this->input->post('mdp_actu');
            $mdp_nouveau = $this->input->post('mdp_nouv');
            $mdp_confirm = $this->input->post('conf_mdp');
            $salt = "monsel";
            $mdp_actuel = hash('sha256', $salt.$mdp_actuel);
            $mdp_nouveau = hash('sha256', $salt.$mdp_nouveau);
            $mdp_confirm = hash('sha256', $salt.$mdp_confirm);
            if ($this->db_model->connect_compte($username, $mdp_actuel)) {
                if(strcmp($mdp_nouveau, $mdp_confirm) == 0){
                    $this->db_model->change_mdp($mdp_actuel, $mdp_nouveau);
                    $this->load->view('templates/menu_administrateur');
                    $this->load->view('compte_changer_mdp');
                    $this->load->view('templates/bas');
                }else {
                    $this->load->view('templates/menu_administrateur');
                    $this->load->view('page_erreur_changer_mdp_invite');
                    $this->load->view('templates/bas');
                }
            } else {
                $this->load->view('templates/menu_administrateur');
                $this->load->view('page_erreur_changer_mdp_admin');
                $this->load->view('templates/bas');
            }
    }}
else {
            redirect('compte/connecter', 'refresh');
        }}

    public function changer_informations()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['inv'] = $this->db_model->get_invite_info($username);
        if ($statut->cpt_statut == 'I') {
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->form_validation->set_rules('nom', 'nom', 'required');
            $this->form_validation->set_rules('prenom', 'prenom', 'required');
            $this->form_validation->set_rules('discipline', 'discipline', 'required');
            if ($this->form_validation->run() == FALSE) {
                $this->load->view('templates/menu_back_invite');
                $this->load->view('page_compte_invite');
                $this->load->view('templates/bas');
            } else {
                $nom = $this->input->post('nom');
                $prenom = $this->input->post('prenom');
                $discipline = $this->input->post('discipline');
                if ($nom == null || $prenom == null || $discipline == null) {
                    echo "Champs de saisie vides";
                    redirect('compte/changer_informations', 'refresh');
                }
                if ($this->db_model->changer_informations($username, $nom, $prenom, $discipline)) {
                    $this->load->view('templates/menu_administrateur');
                    $this->load->view('page_profil_invite', $data);
                    $this->load->view('templates/bas');
                }

            }
        }
    }

    public function animation()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        if ($statut->cpt_statut == 'O') {
            $data['anim'] = $this->db_model->get_animation();
            $this->load->view('templates/menu_administrateur');
            $this->load->view('programmation_administrateur', $data);
            $this->load->view('templates/bas');
        }else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function supprimer_animation($id)
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        $data['anim'] = $this->db_model->get_detail_anim($id);
        if ($statut->cpt_statut == 'O') {
            $this->load->view('templates/menu_administrateur');
            $this->load->view('confirmation_suppr_anim', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function conf_supprimer_animation($id)
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        if ($statut->cpt_statut == 'O') {
            $data['anim'] = $this->db_model->get_animation();
            if ($this->db_model->delete_animation($id)) {
                redirect('compte/accueil_admin', 'refresh');
            } else {
                $this->load->view('templates/menu_administrateur');
                $this->load->view('programmation_administrateur', $data);
                $this->load->view('templates/bas');
            }
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }

    public function ajout_post()
    {
        $this->load->helper('form');
        $this->load->library('form_validation');
        $this->form_validation->set_rules('passid', 'passid', 'required');
        $this->form_validation->set_rules('passmdp', 'passsmdp', 'required');
        $this->form_validation->set_rules('textepost', 'textepost', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/menu_visiteur');
            $this->load->view('ajout_post');
            $this->load->view('templates/bas');
        } else {
            $passid = $this->input->post('passid');
            $passmdp = $this->input->post('passmdp');
            $textepost = addslashes($this->input->post('textepost'));
            if ($this->db_model->pass_verif($passid, $passmdp)) {
                $this->db_model->add_post($passid, $textepost);
                redirect('accueil/afficher', 'refresh');
            } else {
                $this->load->view('templates/menu_visiteur');
                $this->load->view('page_erreur_ajout_post');
                $this->load->view('templates/bas');
            }
        }
    }

    public function pass_post_invite()
    {
        $username = $this->session->userdata('username');
        $statut = $this->db_model->get_user_status($username);
        if ($statut->cpt_statut == 'I') {
            $data['pass_posts'] = $this->db_model->get_passport_post($username);
            $this->load->view('templates/menu_back_invite');
            $this->load->view('page_pass_invite', $data);
            $this->load->view('templates/bas');
        } else {
            redirect('compte/connecter', 'refresh');
        }
    }
}

?>
