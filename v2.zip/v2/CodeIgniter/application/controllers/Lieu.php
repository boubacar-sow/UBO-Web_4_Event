<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Lieu extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('db_model');
        $this->load->helper('url');
    }


    public function afficher()
    {
        $data['lieux'] = $this->db_model->get_lieux();
//Chargement de la view menu_lieu.php
        $this->load->view('templates/menu_lieu');
//Chargement de la view du milieu : page_lieu.php
        $this->load->view('page_lieu', $data);
//Chargement de la view bas.php
        $this->load->view('templates/bas');
    }
    public function lieu_anim($id)
    {
        $data['lieux'] = $this->db_model->get_lieu_anim($id);
//Chargement de la view menu_lieu.php
        $this->load->view('templates/menu_lieu');
//Chargement de la view du milieu : page_lieu.php
        $this->load->view('page_lieu', $data);
//Chargement de la view bas.php
        $this->load->view('templates/bas');
    }
}

?>