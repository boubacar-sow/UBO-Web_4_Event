<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Invite extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('db_model');
        $this->load->helper('url_helper');
    }

    public function afficher()
    {
        $data['titre'] = 'Galerie des invités';
        $data['inv'] = $this->db_model->get_all_guests();
        $data['urls'] = $this->db_model->get_all_urls();
        $data['post'] = $this->db_model->get_all_post();
        $this->load->view('templates/menu_invite');
        $this->load->view('invites', $data);
        $this->load->view('templates/bas');
    }
}

?>