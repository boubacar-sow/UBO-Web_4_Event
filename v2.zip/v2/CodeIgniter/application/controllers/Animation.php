<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Animation extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('db_model');
        $this->load->helper('url');
    }


    public function afficher()
    {
        $data['anim'] = $this->db_model->get_animation();
        $data['next_anim'] = $this->db_model->get_next_animation();
//Chargement de la view menu_visiteur.php
        $this->load->view('templates/menu_programmation');
//Chargement de la view du milieu : programmation.php
        $this->load->view('programmation', $data);
//Chargement de la view bas.php
        $this->load->view('templates/bas');
    }
    public function detail_animation($id)
    {
        $data['anim'] = $this->db_model->get_animation();
        $data['ani_detail'] = $this->db_model->get_detail_anim($id);
        $data['serv'] = $this->db_model->get_serv_animation($id);
        $this->load->view('templates/menu_programmation');
        //Chargement de la view du milieu : programmation.php
        $this->load->view('detail_programmation', $data);
        //Chargement de la view bas.php
        $this->load->view('templates/bas');
    }

    public function galerie_animation($id){
        $data['inv'] = $this->db_model->get_all_guests_anim($id);
        $data['urls'] = $this->db_model->get_all_urls_anim($id);
        $data['serv'] = $this->db_model->get_serv_animation($id);
        $data['post'] = $this->db_model->get_all_post();
        $this->load->view('templates/menu_invite');
        $this->load->view('invites', $data);
        $this->load->view('templates/bas');
    }

}

?>