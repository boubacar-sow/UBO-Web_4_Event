<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Accueil extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('db_model');
        $this->load->helper('url');
    }

    public function afficher()
    {
        $data['titre'] = 'Table des actualités :';
        $data['actu'] = $this->db_model->get_actualite();
        $data['last_actu'] = $this->db_model->get_last_actu();
//Chargement de la view menu_visiteur.php
        $this->load->view('templates/menu_visiteur');
//Chargement de la view du milieu : page_accueil.php
        $this->load->view('page_accueil', $data);
//Chargement de la view du milieu : programmation.php
//Chargement de la view bas.php
        $this->load->view('templates/bas');
    }
}

?>