<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Eventify - Event and Conference Template</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">

    <!--====== Flaticon css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/flaticon.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/LineIcons.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/animate.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/util.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/main.css">

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
          href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
          href="<?php echo base_url(); ?>assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css"
          href="<?php echo base_url(); ?>assets/vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->


</head>

<body>

<!--====== PRELOADER PART START ======-->

<div class="preloader">
    <div class="loader">
        <div class="ytp-spinner">
            <div class="ytp-spinner-container">
                <div class="ytp-spinner-rotator">
                    <div class="ytp-spinner-left">
                        <div class="ytp-spinner-circle"></div>
                    </div>
                    <div class="ytp-spinner-right">
                        <div class="ytp-spinner-circle"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--====== PRELOADER PART ENDS ======-->

<!--====== HEADER PART START ======-->

<header class="header-area">
    <div class="navbar-area navbar-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="<?php echo base_url(); ?>index.html">
                            <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo">
                        </a>

                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo"
                                aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                            <ul class="navbar-nav m-auto" style = 'font-family: bradley Hand'>
                                <li class="nav-item active">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/accueil/afficher/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/animation/afficher/">Programmation</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/invite/afficher/">Invités</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/lieu/afficher/">Lieux</a>
                                </li>
                            </ul>
                        </div>

                        <div class="navbar-btn d-none d-sm-inline-block">
                            <a class="main-btn" href="<?php echo base_url();?>index.php/compte/creer/">Register</a>
                            <a class="main-btn" href="<?php echo base_url();?>index.php/compte/connecter/">Login</a>
                        </div>
                    </nav> <!-- navbar -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>
    <div id="home" class="header-content-area bg_cover d-flex align-items-center"
         style="background-image: url(<?php echo base_url(); ?>assets/images/accueil.jpg)">
        <div id="home" class="header-content-area bg_cover d-flex align-items-center">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="text-center" style="color: white">
                        <span style="font-family: Calibri; font-size: 90px"> Eventify</span>
                        <p style="color: white; font-size: 40px; font-family: Alef">10 Octobre 2021 Au 31 Janvier 2022 en France</p>
                    </div>
                    <div class="col-lg-10">
                        <div class="header-content text-center">
                            <ul class="header-btn">
                                <li><a class="main-btn main-btn-2" href="<?php echo base_url();?>index.php/compte/creer/">Register Now</a></li>
                                <li><a class="main-btn main-btn-2" href="<?php echo base_url();?>index.php/compte/connecter/">Login</a></li>
                            </ul>
                        </div>  <!-- header content -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- header content -->
    </div> <!-- header content -->
</header>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        background: linear-gradient(to right, #b92b27, #1565c0)
    }

    .card {
        margin-bottom: 20px;
        border: none
    }

    .box {
        width: 500px;
        padding: 40px;
        position: absolute;
        top: 50%;
        left: 50%;
        background: #191919;;
        text-align: center;
        transition: 0.25s;
        margin-top: 100px
    }

    .box input[type="text"],
    .box input[type="password"] {
        border: 2px;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid blue;
        padding: 10px 10px;
        width: 250px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s
    }

    .box h1 {
        color: white;
        text-transform: uppercase;
        font-weight: 500
    }

    .box input[type="text"]:focus,
    .box input[type="password"]:focus {
        width: 300px;
        border-color: #2ecc71
    }

    .box input[type="submit"] {
        border: 0;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid #2ecc71;
        padding: 14px 40px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s;
        cursor: pointer
    }

    .box input[type="submit"]:hover {
        background: #2ecc71
    }

    .forgot {
        text-decoration: underline
    }

    ul.social-network {
        list-style: none;
        display: inline;
        margin-left: 0 !important;
        padding: 0
    }

    ul.social-network li {
        display: inline;
        margin: 0 5px
    }

    .social-network a.icoFacebook:hover {
        background-color: #3B5998
    }

    .social-network a.icoTwitter:hover {
        background-color: #33ccff
    }

    .social-network a.icoGoogle:hover {
        background-color: #BD3518
    }

    .social-network a.icoFacebook:hover i,
    .social-network a.icoTwitter:hover i,
    .social-network a.icoGoogle:hover i {
        color: #fff
    }

    a.socialIcon:hover,
    .socialHoverClass {
        color: #44BCDD
    }

    .social-circle li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        border-radius: 50%;
        text-align: center;
        width: 50px;
        height: 50px;
        font-size: 20px
    }

    .social-circle li i {
        margin: 0;
        line-height: 50px;
        text-align: center
    }

    .social-circle li a:hover i,
    .triggeredHover {
        transform: rotate(360deg);
        transition: all 0.2s
    }

    .social-circle i {
        color: #fff;
        transition: all 0.8s;
        transition: all 0.8s
    }

</style>