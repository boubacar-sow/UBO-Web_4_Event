<!--====== FOOTER PART START ======-->

<section id="footer" class="vh-100" style="">
    <div class="footer-subscribe-area pt-120 pb-130">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="footer-subscribe text-center">
                        <h2 class="subscribe-title">Subscribe Now</h2>
                        <div class="subscribe-form mt-45">
                            <form action="#">
                                <input type="email" placeholder="Enter Your Email">
                                <button class="main-btn">Subscribe Now</button>
                            </form>
                        </div>
                    </div> <!-- footer subscribe -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- footer subscribe -->

    <div class="footer-widget">
        <div class="container">
            <div class="widget  pt-80 pb-130">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="footer-address mt-40">
                            <h5 class="f-title">Eventify</h5>
                            <p class="text">10 Novembre 2021 - 31 Janvier 2022<br>Théâtre André-Malraux</p>
                            <a class="contact-link" href="#">Nous contacter</a>
                        </div> <!-- footer address -->
                    </div>
                    <div class="col-lg-6">
                        <div class="footer-contact mt-40">
                            <h5 class="f-title">Retrouvez nous sur les réseaux sociaux</h5>
                            <p class="text">Revoyez toutes les images et vidéos des différents évenements sur nos réseaux sociaux</p>
                            <ul class="social">
                                <li><a href="#"><i class="lni-facebook-filled"></i></a></li>
                                <li><a href="#"><i class="lni-twitter-original"></i></a></li>
                                <li><a href="#"><i class="lni-linkedin-original"></i></a></li>
                                <li><a href="#"><i class="lni-instagram-original"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- widget -->
        </div> <!-- container -->
    </div> <!-- footer widget -->

    <div class="footer-copyright">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="copyright text-center">
                        <p class="text">Template Designed and Developed by <a href="https://graygrids.com/" rel="nofollow">GrayGrids et Boubacar SOW</a>. All Rights Reserved by Us</p>
                    </div> <!-- copyright -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- container -->
</section>

<!--====== FOOTER PART ENDS ======-->

<!--====== BACK TOP TOP PART START ======-->

<a href="#" class="back-to-top"><i class="lni-chevron-up"></i></a>

<!--====== BACK TOP TOP PART ENDS ======-->

<!--====== PART START ======-->

<!--
    <section class="">
        <div class="container">
            <div class="row">
                <div class="col-lg-">

                </div>
            </div>
        </div>
    </section>
-->

<!--====== PART ENDS ======-->

<!-- row -->










<!--====== jquery js ======-->
<script src="<?php echo base_url();?>assets/js/vendor/modernizr-3.6.0.min.js"></script>
<script src="<?php echo base_url();?>assets/js/vendor/jquery-1.12.4.min.js"></script>

<!--====== Bootstrap js ======-->
<script src="<?php echo base_url();?>assets/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>assets/js/popper.min.js"></script>

<!--====== Counter Up js ======-->
<script src="<?php echo base_url();?>assets/js/waypoints.min.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.counterup.min.js"></script>

<!--====== Slick js ======-->
<script src="<?php echo base_url();?>assets/js/slick.min.js"></script>

<!--====== Magnific Popup js ======-->
<script src="<?php echo base_url();?>assets/js/jquery.magnific-popup.min.js"></script>

<!--====== Scrolling Nav js ======-->
<script src="<?php echo base_url();?>assets/js/jquery.easing.min.js"></script>
<script src="<?php echo base_url();?>assets/js/scrolling-nav.js"></script>

<!--====== Countdown js ======-->
<script src="<?php echo base_url();?>assets/js/jquery.countdown.min.js"></script>

<!--====== wow js ======-->
<script src="<?php echo base_url();?>assets/js/wow.min.js"></script>

<!--====== Ajax Contact js ======-->
<script src="<?php echo base_url();?>assets/js/ajax-contact.js"></script>

<!--====== Main js ======-->
<script src="<?php echo base_url();?>assets/js/main.js"></script>

</body>

</html>

