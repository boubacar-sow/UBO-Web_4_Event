<!doctype html>
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Eventify - Event and Conference Template</title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css">

    <!--====== Flaticon css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/flaticon.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/LineIcons.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/animate.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/slick.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/util.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/main.css">

    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/vendor/perfect-scrollbar/perfect-scrollbar.css">
    <!--===============================================================================================-->




</head>

<body>

<!--====== PRELOADER PART START ======-->

<div class="preloader">
    <div class="loader">
        <div class="ytp-spinner">
            <div class="ytp-spinner-container">
                <div class="ytp-spinner-rotator">
                    <div class="ytp-spinner-left">
                        <div class="ytp-spinner-circle"></div>
                    </div>
                    <div class="ytp-spinner-right">
                        <div class="ytp-spinner-circle"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!--====== PRELOADER PART ENDS ======-->

<!--====== HEADER PART START ======-->

<header class="header-area">
    <div class="navbar-area navbar-two">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg">
                        <a class="navbar-brand" href="<?php echo base_url();?>index.html">
                            <img src="<?php echo base_url();?>assets/images/logo.png" alt="Logo">
                        </a>

                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTwo" aria-controls="navbarTwo" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                            <span class="toggler-icon"></span>
                        </button>

                        <div class="collapse navbar-collapse sub-menu-bar" id="navbarTwo">
                            <ul class="navbar-nav m-auto" style = 'font-family: bradley Hand'>
                                <li class="nav-item">
                                    <a class="page-scroll active" href="<?php echo base_url();?>index.php/compte/accueil_admin/">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/compte/changer_mdp_admin/">Compte</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/compte/afficher_profil_admin/">Mon profil</a>
                                </li>
                                <li class="nav-item">
                                    <a class="page-scroll" href="<?php echo base_url();?>index.php/compte/animation/">Programmation</a>
                                </li>
                            </ul>
                        </div>

                        <div class="navbar-btn d-none d-sm-inline-block">
                            <a class="main-btn" href="<?php echo base_url();?>index.php/compte/deconnecter/">Déconnexion</a></a>
                        </div>
                    </nav> <!-- navbar -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div>

</header>