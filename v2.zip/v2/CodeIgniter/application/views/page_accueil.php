<section id="about" class="about-area pb-130 pt-80" style="color: white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-image mt-50 wow fadeInLeft" data-wow-duration="1s">
                    <img src="<?php echo base_url(); ?>assets/images/actu.jpg" alt="About">
                </div> <!-- about image -->
            </div>
            <div class="col-lg-6">
                <div class="about-content mt-45 wow fadeInRight" data-wow-duration="1s">
                    <div class="section-title">
                        <h2 class="title">Dernière actualité</h2>
                    </div> <!-- section title -->

                    <p class="text mt-30"><?php
                        if (isset($last_actu)){
                        echo $last_actu->texte; ?>
                    <p class="date">
                        <span><?php echo date('d', strtotime($last_actu->date)); ?><sup>th</sup></span> <?php echo date('F, Y', strtotime($last_actu->date)); ?>
                    </>
                    <?php } else echo "<h3> Aucun résultat </h3>";
                    ?>
                </div> <!-- about content -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>
<section class="features-area pt-115 pb-130" style="align:center">
    <h2 align="center">Toutes les actualités</h2>
    <div class="limiter" align="center">
        <div class="table table-striped">
            <table>
                <?php
                if ($actu != NULL){
                ?>
                <thead class="">
                <tr>
                    <th>Titre</th>
                    <th>Texte</th>
                    <th>Date</th>
                    <th>Auteur</th>
                </tr>
                </thead>
                <tbody>
                <?php
                foreach ($actu as $act) {
                    echo '<tr class="row100 body">';
                    echo "<td>";
                    echo $act["act_intitule"];
                    echo "</td>";
                    echo "<td>";
                    echo $act["act_texte"];
                    echo "</td>";
                    echo "<td>";
                    echo $act["act_date"];
                    echo "</td>";
                    echo "<td>";
                    echo $act["cpt_pseudo"];
                    echo "</td>";
                    echo "</tr>";
                } ?>
                <?php
                } else {
                    echo "</br>";
                    echo "<h3 align='center'>Aucun résultat</h3>";
                }
                ?>
                </tbody>
            </table>
        </div>
    </div>
</section>
<section color="white">
    <div class="centered">
        <br><br><br>
        <h2 align="center" >Ajouter un post en cliquant sur le bouton + ci-dessous</h2>
        <div class="centered" style="text-align: center">
            <a href="<?php echo base_url();?>index.php/compte/ajout_post">
                <Type Bouton='button' class='btn btn-info subscribe-submit' type='submit' style="width:250px">+</Type>
            </a>
        </div>
    </div>
</section>

<style>
    h2{
        color: white;
    }
</style>
