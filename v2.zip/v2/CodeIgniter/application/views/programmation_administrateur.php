<section class="features-area pt-115 pb-130 gray-bg">
    <p class="text mt-30">
    <h2 align="center" , style="font-size: 40px">Toutes les animations</h2></p>
    <div align="center">
        <a class="btn btn-info"
           href="https://obiwan2.univ-brest.fr/licence/lic101/dev/CodeIgniter/index.php/compte/creer/">Ajouter une
            animation</a>
    </div>
    <div align="center">
        <?php
        if ($anim != NULL) {
            ?>
            <div class="limiter">
                <div class="table table-striped">
                    <table>
                        <thead class="table-info">
                        <tr>
                            <th>Intitule</th>
                            <th>Debut</th>
                            <th>Fin</th>
                            <th>Invité.s</th>
                            <th>Lieu</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        echo "<td colspan='9' style='text-align:center; color: green'>";
                        echo "ANIMATIONS PASSEES";
                        echo "</td>";
                        $nb_anim = 0;
                        foreach ($anim

                        as $ani) {
                        if ($ani["fin"] < date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo "<s>";
                        echo $ani["ani_intitule"];
                        echo "</s>";
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["invites"]) echo "Aucun invité";
                        else echo $ani["invites"];
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["lieu"]) echo "Aucun lieu";
                        else {
                            echo $ani["lieu"];
                            echo "<br>";
                            echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                            echo '<img src="https://img.icons8.com/office/16/000000/map-marker.png"/>';
                            echo "Plus d'infos";
                            echo "</button>";
                        }
                        echo "</td>";
                        echo "<td>";
                        echo "<table>";
                        echo "<tbody>";
                        echo "<tr>";
                        echo "<td>"; ?>
                        <a href=<?php echo base_url(); ?>index.php/compte/supprimer_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='fa fa-trash'></i>";
                        echo "Supprimer une animation";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'> ";
                        echo "<i class='material-icons'></i>";
                        echo "Modifier cette animation";
                        echo "</button>";
                        echo "</td>";
                        echo "</tr>";
                        echo "</tbody>";
                        echo "</table>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation passée";
                            echo "</td>";
                            echo "</tr>";
                        }
                        echo "<tr>";
                        echo "<td colspan='9' style='text-align:center; color:green'>";
                        echo "ANIMATIONS EN COURS";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim = 0;
                        foreach ($anim

                        as $ani) {
                        if ($ani["fin"] > date("Y-m-d H:i:s") && $ani["debut"] < date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo $ani["ani_intitule"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["invites"]) echo "Aucun invité";
                        else echo $ani["invites"];
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["lieu"]) echo "Aucun lieu";
                        else {
                            echo $ani["lieu"];
                            echo "<br>";
                            echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                            echo '<img src="https://img.icons8.com/office/16/000000/map-marker.png"/>';
                            echo "Plus d'infos";
                            echo "</button>";
                        }
                        echo "</td>";
                        echo "<td>";
                        echo "<table>";
                        echo "<tbody>";
                        echo "<tr>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/compte/supprimer_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='fa fa-trash'></i>";
                        echo "Supprimer une animation";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/compte/supprimer_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='fa fa-trash'></i>";
                        echo "Modifier une animation";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        echo "</tbody>";
                        echo "</table>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation en cours";
                            echo "</td>";
                            echo "</tr>";
                        }
                        echo "<td colspan='9' style='text-align:center; color: green'>";
                        echo "ANIMATIONS FUTURES";
                        echo "</td>";
                        $nb_anim = 0;
                        foreach ($anim

                        as $ani) {
                        if ($ani["debut"] > date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo $ani["ani_intitule"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        if ($ani["invites"]) echo $ani["invites"];
                        else echo "Aucun invité";
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["lieu"]) echo "Aucun lieu";
                        else {
                            echo $ani["lieu"];
                            echo "<br>";
                            echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                            echo '<img src="https://img.icons8.com/office/16/000000/map-marker.png"/>';
                            echo "Plus d'infos";
                            echo "</button>";
                        }
                        echo "</td>";
                        echo "<td>";
                        echo "<table>";
                        echo "<tbody>";
                        echo "<tr>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/compte/supprimer_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='fa fa-trash'></i>";
                        echo "Supprimer une animation";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        echo "<tr>";
                        echo "<td>";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'> ";
                        echo "<i class='material-icons'></i>";
                        echo "Modifier cette animation";
                        echo "</button>";
                        echo "</td>";
                        echo "</tr>";
                        echo "</tbody>";
                        echo "</table>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation à venir";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
</tbody>
                    </table>
                </div>
            </div>
            <?php
        } else {
            echo "</br>";
            echo "Aucune animation pour l'instant";
        }
        ?>
    </div>
</section>

<!--====== FEATURES PART START ======-->

<section id="features" class="features-area pt-115 pb-130 gray-bg">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="section-title text-center pb-20">
                    <h2 class="title">Why You Should Join?</h2>
                    <p class="text">Lorem ipsum dolor sit amet, in quodsi vulputate pro. Ius illum vocent mediocritatem
                        reiciendis odit sed, vero amet blanditiis cule dicta iriure at phaedrum.</p>
                </div> <!-- section title -->
            </div>
        </div> <!-- row -->
        <div class="row justify-content-center">
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0s">
                    <div class="features-icon">
                        <i class="lni-microphone"></i>
                        <span>01</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">Great Speakers</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                    <div class="features-icon">
                        <i class="lni-users"></i>
                        <span>02</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">New People</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1s">
                    <div class="features-icon">
                        <i class="lni-bullhorn"></i>
                        <span>03</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">Global Event</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="0.5s">
                    <div class="features-icon">
                        <i class="lni-heart"></i>
                        <span>04</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">Get Inspired</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1s">
                    <div class="features-icon">
                        <i class="lni-cup"></i>
                        <span>05</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">Networking Session</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="single-features text-center mt-30 wow fadeIn" data-wow-duration="1s" data-wow-delay="1.5s">
                    <div class="features-icon">
                        <i class="lni-gallery"></i>
                        <span>06</span>
                    </div>
                    <div class="features-content">
                        <h4 class="features-title"><a href="#">Meet New Faces</a></h4>
                        <p class="text">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor
                            dunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</p>
                    </div>
                </div> <!-- single features -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>
