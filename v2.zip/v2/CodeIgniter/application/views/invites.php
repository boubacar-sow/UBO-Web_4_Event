<section>
<div id="home" class="header-content-area bg_cover d-flex align-items-center"
     style="background-image: url(<?php echo base_url(); ?>assets/images/accueil.jpg)">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-10">

            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</div> <!-- header content -->
</section>
<section class="galery">
    <h1 class = 'card-title' align='center'>Invités</h1>;
    <?php
    if ($inv!= null) {
        echo "<div class='card-body'>";
        // Boucle de parcours de toutes les lignes du résultat obtenu
        foreach ($inv as $invite) {
            if (!isset($traite[$invite['nom']])) {
                $inv_pseudo = $invite['pseudo_inv'];
                echo "<div class = 'contain'>";
                echo "<h3 class='card-title'>";
                echo $invite['nom'];
                echo "</h3>";
                echo "<img src='";
                echo base_url();
                echo "assets/images/";
                echo $invite['photo'];
                echo "'";
                echo "class='card-img-top' width = '350' height = '350' />";
                echo "<p class='card-text'>";
                echo $invite['discipline'];
                echo "</p>";
                if ($invite['res_id'] == NULL) {
                    echo "<p align='center'>Pas de réseau social pour cet invité ! </p>";
                } else {
                    echo "<div class= 'reseaux' align='center'>";
                    echo "<table class='table table-condensed'>";
                    echo "<tbody>";
                    echo "<tr>";
                    foreach ($urls as $inv_url) {

                        if (strcmp($inv_pseudo, $inv_url['res_pseudo']) == 0) {
                            echo "<td>";
                            echo "<a href = '";
                            echo $inv_url['res_lien'];
                            if (strcmp($inv_url['res_nom'], "facebook") == 0) {
                                echo "'class='fa fa-facebook' style='font-size: 20px;'>";
                                echo "Facebook";
                            } else if (strcmp($inv_url['res_nom'], "instagram") == 0) {
                                echo "'class='fa fa-instagram' style='font-size: 20px;'>";
                                echo "Instagram";
                            } else {
                                echo "'class='fa fa-twitter' style='font-size: 20px;'>";
                                echo "Twitter";
                            }
                            echo "</a>";
                            echo "</td><br>";
                            // Conservation du traitement du nom de l'invité
                            $traite[$invite["nom"]] = 1;
                        }
                    }
                    echo "</tr>";
                    echo "</tbody>";
                    echo "</table>";
                    echo "</div>";
                }
                echo "<br>";
                echo "<h3 align='center'> DERNIERS POSTS : </h3>";
                if ($invite['texte_post'] == NULL) {

                    echo "<p align='center'>Pas de post pour cet invité ! </p>";
                } else {
                    echo "<table class='table table-condensed'>";
                    echo "<tbody>";
                    if ($invite['texte_post'] == NULL && $invite["date_post"] == NULL) {
                        echo "Pas de posts disponible !";
                    } else {
                        foreach ($post as $post_invite) {
                                 if (strcmp($inv_pseudo, $post_invite['Pseudo']) == 0) {
                                     echo "<tr>";
                                     echo "<td>";
                                     echo "<span style='font-weight: bold;'>";
                                     echo date('m/d', strtotime($post_invite['Date_p']));
                                     echo "</span>";
                                     echo " ";
                                     echo $post_invite['Libelle'];
                                     echo "</td>";
                                     $traite[$invite["nom"]] = 1;
                                     echo "</tr>";
                                 }

                        }
                    }
                    echo "</tbody>";
                    echo "</table>";
                }
                echo "<br><br>";
                echo "</div>";
            }
        }
        echo "</div>";
    } else {
        echo "<p class = 'card-title' align='center'>Aucun invité pour l'instant</p>";
    }
    ?>
</section>
<style>
    .contain {

        border-radius: 20%;
    }

    .reseaux {
        display: flex;
    }

    .card-body {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr;
        margin-left: 150px;
    }

    h1, h3 {
        font-weight: bolder;
        color: #f3456e;
        text-transform: uppercase;

    }

    a {
        font-size: 15px;
    }
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        background: linear-gradient(to right, #b92b27, #1565c0)
    }

    .card {
        margin-bottom: 20px;
        border: none
    }

    .box {
        width: 500px;
        padding: 40px;
        position: absolute;
        top: 50%;
        left: 50%;
        background: #191919;;
        text-align: center;
        transition: 0.25s;
        margin-top: 100px
    }

    .box input[type="text"],
    .box input[type="password"] {
        border: 2px;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid blue;
        padding: 10px 10px;
        width: 250px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s
    }

    .box h1 {
        color: white;
        text-transform: uppercase;
        font-weight: 500
    }

    .box input[type="text"]:focus,
    .box input[type="password"]:focus {
        width: 300px;
        border-color: #2ecc71
    }

    .box input[type="submit"] {
        border: 0;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid #2ecc71;
        padding: 14px 40px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s;
        cursor: pointer
    }

    .box input[type="submit"]:hover {
        background: #2ecc71
    }

    .forgot {
        text-decoration: underline
    }

    ul.social-network {
        list-style: none;
        display: inline;
        margin-left: 0 !important;
        padding: 0
    }

    ul.social-network li {
        display: inline;
        margin: 0 5px
    }

    .social-network a.icoFacebook:hover {
        background-color: #3B5998
    }

    .social-network a.icoTwitter:hover {
        background-color: #33ccff
    }

    .social-network a.icoGoogle:hover {
        background-color: #BD3518
    }

    .social-network a.icoFacebook:hover i,
    .social-network a.icoTwitter:hover i,
    .social-network a.icoGoogle:hover i {
        color: #fff
    }

    a.socialIcon:hover,
    .socialHoverClass {
        color: #44BCDD
    }

    .social-circle li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        border-radius: 50%;
        text-align: center;
        width: 50px;
        height: 50px;
        font-size: 20px
    }

    .social-circle li i {
        margin: 0;
        line-height: 50px;
        text-align: center
    }

    .social-circle li a:hover i,
    .triggeredHover {
        transform: rotate(360deg);
        transition: all 0.2s
    }

    .social-circle i {
        color: #fff;
        transition: all 0.8s;
        transition: all 0.8s
    }
    @media (max-width: 450px) {

        .card-body {
            font-family: 'Roboto', sans-serif;
            display: flex;
        }
    }

    .galery {
        font-family: 'Roboto', sans-serif;
    }
    .fa-facebook {
        background: #3B5998;
        color: white;
        width: auto;
    }
</style>