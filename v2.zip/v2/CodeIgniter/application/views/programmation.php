<section>
    <div id="home" class="header-content-area bg_cover d-flex align-items-center"
         style="background-image: url(<?php echo base_url(); ?>assets/images/accueil.jpg)">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="header-content text-center">
                        <h2 class="header-title" style='font-family: bradley Hand'>Prochaine Animation</h2>
                        <div data-countdown="<?php echo date('Y/m/d', strtotime($next_anim->debut)); ?>"></div>
                        <h3 class="sub-title" style='font-family: bradley Hand'><?php
                            echo $next_anim->debut;
                            echo " ";
                            echo $next_anim->lieu;
                            ?></h3>
                    </div>  <!-- header content -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </div> <!-- header content -->
</section>
<!--====== ABOUT PART START ======-->

<section id="about" class="about-area pb-130 pt-80">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <div class="about-image mt-50 wow fadeInLeft" data-wow-duration="1s">
                    <img src="<?php echo base_url(); ?>assets/images/about.png" alt="About">
                </div> <!-- about image -->
            </div>
            <div class="col-lg-6">
                <div class="about-content mt-45 wow fadeInRight" data-wow-duration="1s">
                    <div class="section-title">
                        <h2 class="title"><?php echo $next_anim->intitule ?></h2>
                    </div> <!-- section title -->

                    <p class="text mt-30"><?php echo $next_anim->description ?></p>
                    <p class="date">
                        <span><?php echo date('d', strtotime($next_anim->debut)); ?><sup>th</sup></span> <?php echo date('F, Y', strtotime($next_anim->debut)); ?>
                    </p>
                </div> <!-- about content -->
            </div>
        </div> <!-- row -->
    </div> <!-- container -->
</section>

<!--====== ABOUT PART ENDS ======-->
<section class="features-area pt-115 pb-130 gray-bg">
    <p class="text mt-30">
    <h2 align="center" , style="font-size: 40px">Toutes les animations</h2></p>
    <div align="center">
        <?php
        if ($anim != NULL) {
            ?>
            <div class="limiter">
                <div class="table table-striped">
                    <table>
                        <thead class="table-info">
                        <tr>
                            <th>Intitule</th>
                            <th>Debut</th>
                            <th>Fin</th>
                            <th>Invité.s</th>
                            <th>Lieu</th>
                            <th>Détails de l'animation</th>
                            <th>Galerie</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php
                        echo "<td colspan='9' style='text-align:center; color: green'>";
                        echo "ANIMATIONS PASSEES";
                        echo "</td>";
                        $nb_anim = 0;
                        foreach ($anim

                                 as $ani) {
                        if ($ani["fin"] < date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo "<s>";
                        echo $ani["ani_intitule"];
                        echo "</s>";
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        if (!$ani["invites"]) echo "Aucun invité";
                        else echo $ani["invites"];
                        echo "</td>";

                        if (!$ani["lieu"]) {
                            echo "<td>";
                            echo "Aucun lieu";
                            echo "</td>";
                        }
                        else{
                        echo "<td>"; ?>
                        <?php echo $ani["lieu"];
                        echo "<br>"; ?>
                        <a href=<?php echo base_url(); ?>index.php/lieu/lieu_anim/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        }
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/detail_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/galerie_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation passée";
                            echo "</td>";
                            echo "</tr>";
                        }
                        echo "<tr>";
                        echo "<td colspan='9' style='text-align:center; color:green'>";
                        echo "ANIMATIONS EN COURS";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim = 0;
                        foreach ($anim

                        as $ani) {
                        if ($ani["fin"] > date("Y-m-d H:i:s") && $ani["debut"] < date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo $ani["ani_intitule"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["invites"];
                        echo "</td>";
                        if (!$ani["lieu"]) {
                            echo "<td>";
                            echo "Aucun lieu";
                            echo "</td>";
                        }
                        else{
                        echo "<td>"; ?>
 <?php echo $ani["lieu"];
                        echo "<br>"; ?>
                        <a href=<?php echo base_url(); ?>index.php/lieu/lieu_anim/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        }
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/detail_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/galerie_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation en cours";
                            echo "</td>";
                            echo "</tr>";
                        }
                        echo "<td colspan='9' style='text-align:center; color: green'>";
                        echo "ANIMATIONS FUTURES";
                        echo "</td>";
                        $nb_anim = 0;
                        foreach ($anim

                        as $ani) {
                        if ($ani["debut"] > date("Y-m-d H:i:s")) {
                        echo '<tr>';
                        echo "<td>";
                        echo $ani["ani_intitule"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["debut"];
                        echo "</td>";
                        echo "<td>";
                        echo $ani["fin"];
                        echo "</td>";
                        echo "<td>";
                        if ($ani["invites"]) echo $ani["invites"];
                        else echo "Aucun invité";
                        echo "</td>";
                        if (!$ani["lieu"]) {
                            echo "<td>";
                            echo "Aucun lieu";
                            echo "</td>";
                        }
                        else{
                        echo "<td>"; ?>
 <?php echo $ani["lieu"];
                        echo "<br>"; ?>
                        <a href=<?php echo base_url(); ?>index.php/lieu/lieu_anim/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        }
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/detail_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "<td>"; ?>
 <a href=<?php echo base_url(); ?>index.php/animation/galerie_animation/<?php echo $ani["id"];
                        echo ">";
                        echo "<Type Bouton = 'button' class = 'btn btn-primary subscribe-submit' type='submit'>";
                        echo "<i class='material-icons'>group</i>";
                        echo "Voir";
                        echo "</button>";
                        echo "</a>";
                        echo "</td>";
                        echo "</tr>";
                        $nb_anim++;
                        }
                        }
                        if ($nb_anim == 0) {
                            echo "<tr>";
                            echo "<td colspan='9' style='text-align:center'>";
                            echo "Aucune animation à venir";
                            echo "</td>";
                            echo "</tr>";
                        }
                        ?>
</tbody>
                    </table>
                </div>
            </div>
            <?php
        } else {
            echo "</br>";
            echo "Aucune animation pour l'instant";
        }
        ?>
    </div>
</section>


<style>
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        background: linear-gradient(to right, #b92b27, #1565c0)
    }

    .card {
        margin-bottom: 20px;
        border: none
    }

    .box {
        width: 500px;
        padding: 40px;
        position: absolute;
        top: 50%;
        left: 50%;
        background: #191919;;
        text-align: center;
        transition: 0.25s;
        margin-top: 100px
    }

    .box input[type="text"],
    .box input[type="password"] {
        border: 2px;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid blue;
        padding: 10px 10px;
        width: 250px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s
    }

    .box h1 {
        color: white;
        text-transform: uppercase;
        font-weight: 500
    }

    .box input[type="text"]:focus,
    .box input[type="password"]:focus {
        width: 300px;
        border-color: #2ecc71
    }

    .box input[type="submit"] {
        border: 0;
        background: none;
        display: block;
        margin: 20px auto;
        text-align: center;
        border: 2px solid #2ecc71;
        padding: 14px 40px;
        outline: none;
        color: white;
        border-radius: 24px;
        transition: 0.25s;
        cursor: pointer
    }

    .box input[type="submit"]:hover {
        background: #2ecc71
    }

    .forgot {
        text-decoration: underline
    }

    ul.social-network {
        list-style: none;
        display: inline;
        margin-left: 0 !important;
        padding: 0
    }

    ul.social-network li {
        display: inline;
        margin: 0 5px
    }

    .social-network a.icoFacebook:hover {
        background-color: #3B5998
    }

    .social-network a.icoTwitter:hover {
        background-color: #33ccff
    }

    .social-network a.icoGoogle:hover {
        background-color: #BD3518
    }

    .social-network a.icoFacebook:hover i,
    .social-network a.icoTwitter:hover i,
    .social-network a.icoGoogle:hover i {
        color: #fff
    }

    a.socialIcon:hover,
    .socialHoverClass {
        color: #44BCDD
    }

    .social-circle li a {
        display: inline-block;
        position: relative;
        margin: 0 auto 0 auto;
        border-radius: 50%;
        text-align: center;
        width: 50px;
        height: 50px;
        font-size: 20px
    }

    .social-circle li i {
        margin: 0;
        line-height: 50px;
        text-align: center
    }

    .social-circle li a:hover i,
    .triggeredHover {
        transform: rotate(360deg);
        transition: all 0.2s
    }

    .social-circle i {
        color: #fff;
        transition: all 0.8s;
        transition: all 0.8s
    }

</style>
