<br>
<section class="vh-100">
    <div>

    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="box">
                        <h2>Passeports et posts</h2>
                        <?php
                        if ($pass_posts != NULL) {
                            ?>
                            <div class="limiter">
                                <div class="table table-bordered">
                                    <table>
                                        <thead class="table-info">
                                        <tr>
                                            <th>Nom</th>
                                            <th>Prenom</th>
                                            <th>Pseudo</th>
                                            <th>Passeport</th>
                                            <th>Libellé post</th>
                                            <th>Date du post</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        foreach ($pass_posts as $pp) {
                                            echo '<tr>';
                                            echo "<td>";
                                            echo $pp["nom"];
                                            echo "</td>";
                                            echo "<td>";
                                            echo $pp["prenom"];
                                            echo "</td>";
                                            echo "<td>";
                                            echo $pp["pseudo_inv"];
                                            echo "</td>";
                                            if ($pp["pass"] != NULL) {
                                                echo "<td>";
                                                echo $pp["pass"];
                                                echo "</td>";
                                                echo "<td>";
                                                if ($pp["texte_post"] != NULL) echo $pp["texte_post"]; else echo"Aucun post";
                                                echo "</td>";
                                                echo "<td>";
                                                if ($pp["date_post"] != NULL) echo $pp["date_post"]; else echo "Aucun post";
                                                echo "</td>";
                                            } else {
                                                echo "<td>";
                                                echo "Aucun passeport";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "Aucun post";
                                                echo "</td>";
                                                echo "<td>";
                                                echo "Aucun post";
                                                echo "</td>";
                                            }
                                            echo "</tr>";
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <?php
                        } else {
                            echo "</br>";
                            echo "Aucun passeport";
                        }
                        ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: sans-serif;
        background: linear-gradient(to right, #b92b27, #1565c0)
    }

    .card {
        margin-bottom: 20px;
        border: none
    }

    .box {
        width: auto;
        position: absolute;
        top: 50%;
        background: lightblue;
        text-align: center;
        transition: 0.25s;
        margin-top: 100px
    }

</style>
