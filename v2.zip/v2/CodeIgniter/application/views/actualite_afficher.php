<h1><?php echo $titre; ?></h1>
<?php
if ($actu != NULL){
?>
<table class="table table-bordered">
    <thead>
    <tr>
        <th>Intitulé</th>
        <th>Texte</th>
    </tr>
    </thead>
    <tbody>
    <?php
    foreach ($actu as $a) {
        echo "<tr>";
        echo "<td>";
        echo $a["act_intitule"];
            echo "</td>";
        echo "<td>";
        echo $a["act_texte"];
        echo "</td>";
        echo "</tr>";
    }
    } else {
        echo "</br>";
        echo "Aucun résultat";
    }
    ?>

    </tbody>
</table>