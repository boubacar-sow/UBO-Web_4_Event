<?php

class Db_model extends CI_Model
{
    public function __construct()
    {
        $this->load->database();
    }

    public function get_all_compte()
    {
        $query = $this->db->query("SELECT cpt_pseudo FROM t_compte_cpt;");
        return $query->result_array();
    }

    public function get_actualite()
    {
        $query = $this->db->query("SELECT act_intitule, act_texte, act_date, cpt_pseudo FROM t_actualites_act
        JOIN t_organisateur_org USING(org_id)
        WHERE act_etat = 'A'
        ORDER BY act_id DESC
        LIMIT 5;
        ");
        return $query->result_array();
    }

    public function get_animation()
    {
        $query = $this->db->query("SELECT t_animation_ani.ani_id as id, ani_intitule, ani_description, ani_horaire_debut as debut, ani_horaire_fin as fin,
       lie_nom as lieu,GROUP_CONCAT('-', inv_prenom,' ', inv_nom SEPARATOR '<br>') as invites
FROM t_animation_ani
         LEFT OUTER JOIN t_lieu_lie tll on tll.lie_id = t_animation_ani.lie_id
         LEFT OUTER JOIN t_prestation_ani_inv tpai on t_animation_ani.ani_id = tpai.ani_id
         LEFT OUTER JOIN t_invite_inv tii on tpai.cpt_pseudo = tii.cpt_pseudo
GROUP BY(t_animation_ani.ani_id)
ORDER BY ani_horaire_fin");
        return $query->result_array();
    }

    public function get_next_animation()
    {
        $query = $this->db->query("SELECT ani_intitule as intitule, ani_horaire_debut as debut, ani_description as description, lie_nom as lieu
FROM t_animation_ani
         JOIN t_lieu_lie tll on tll.lie_id = t_animation_ani.lie_id
WHERE ani_horaire_debut  > current_date 
ORDER BY debut ASC
LIMIT 1;");
        return $query->row();
    }

    public function get_detail_anim($id)
    {
        $query = $this->db->query("SELECT t_animation_ani.ani_id as id, ani_intitule as intitule, ani_horaire_debut as debut, ani_horaire_fin as fin,  ani_description as description, GROUP_CONCAT('-', inv_prenom,' ', inv_nom SEPARATOR '<br>') as invites, lie_nom as lieu
FROM t_animation_ani
LEFT OUTER JOIN t_lieu_lie tll on tll.lie_id = t_animation_ani.lie_id
LEFT OUTER JOIN t_prestation_ani_inv tpai on t_animation_ani.ani_id = tpai.ani_id
LEFT OUTER JOIN t_invite_inv tii on tpai.cpt_pseudo = tii.cpt_pseudo
WHERE t_animation_ani.ani_id = '" .$id ."';");
        return $query->row();
    }

    public function delete_animation($id)
    {
        $query = $this->db->query("DELETE
FROM t_animation_ani
WHERE ani_id = '" .$id ."';");
        return $query;
    }
    public function get_last_actu()
    {
        $query = $this->db->query("call get_actu();");
        return $query->row();
    }
    public function get_all_guests()
    {
        $query = $this->db->query("SELECT inv_id,
       inv_nom              as nom,
       inv_prenom           as prenom,
       inv_photo            as photo,
       pst_libelle          as texte_post,
       pst_date             as date_post,
       cpt_pseudo           as pseudo_inv,
       inv_discipline       as discipline,
       pst_etat             as etat_post,
       res_id as res_id
FROM t_invite_inv
         LEFT OUTER JOIN t_res_inv USING (cpt_pseudo)
         LEFT JOIN t_passeport_pas USING (inv_id)
         LEFT join t_post_pst tpp on t_passeport_pas.pas_id = tpp.pas_id
ORDER BY date_post DESC ");
        return $query->result_array();
    }

    public function get_all_guests_anim($id)
    {
        $query = $this->db->query("SELECT inv_id,
       inv_nom              as nom,
       inv_prenom           as prenom,
       inv_photo            as photo,
       pst_libelle          as texte_post,
       pst_date             as date_post,
       t_res_inv.cpt_pseudo as pseudo_inv,
       inv_discipline       as discipline,
       pst_etat             as etat_post,
       res_id               as res_id
FROM t_invite_inv
         LEFT OUTER JOIN t_res_inv USING (cpt_pseudo)
         LEFT JOIN t_passeport_pas USING (inv_id)
         LEFT join t_post_pst tpp on t_passeport_pas.pas_id = tpp.pas_id
         LEFT JOIN t_prestation_ani_inv tpai on t_invite_inv.cpt_pseudo = tpai.cpt_pseudo
         LEFT JOIN t_animation_ani taa on tpai.ani_id = taa.ani_id
WHERE taa.ani_id = '".$id."'
ORDER BY date_post DESC");
        return $query->result_array();
    }
    public function get_all_urls_anim($id)
    {
        $query = $this->db->query("SELECT res_nom as res_nom, res_hyperlien as res_lien, t_invite_inv.cpt_pseudo as res_pseudo
FROM t_invite_inv
         LEFT OUTER JOIN t_res_inv USING(cpt_pseudo)
         left outer join t_reseaux_res USING(res_id)
         LEFT OUTER JOIN t_prestation_ani_inv tpai on t_invite_inv.cpt_pseudo = tpai.cpt_pseudo
         LEFT OUTER JOIN t_animation_ani taa on tpai.ani_id = taa.ani_id
WHERE taa.ani_id = '".$id."'");
        return $query->result_array();
    }
    public function  get_serv_animation($id)
    {
        $query = $this->db->query("SELECT GROUP_CONCAT(tss.srv_type SEPARATOR '<br>') as services
FROM t_animation_ani
JOIN t_lieu_lie tll on t_animation_ani.lie_id = tll.lie_id
JOIN t_service_srv tss on tll.lie_id = tss.lie_id
WHERE ani_id = '" .$id. "';");
        return $query->row();
    }
    public function get_all_urls()
    {
        $query = $this->db->query("SELECT res_nom as res_nom, res_hyperlien as res_lien, t_invite_inv.cpt_pseudo as res_pseudo
FROM t_invite_inv
LEFT OUTER JOIN t_res_inv USING(cpt_pseudo)
left outer join t_reseaux_res USING(res_id);");
        return $query->result_array();
    }
    public function get_lieu_anim($id)
    {
        $query = $this->db->query("SELECT lie_nom, lie_description, GROUP_CONCAT('-', srv_type SEPARATOR '<br>') as services
FROM t_lieu_lie
         LEFT OUTER JOIN t_service_srv tss on t_lieu_lie.lie_id = tss.lie_id
        LEFT OUTER JOIN t_animation_ani taa on t_lieu_lie.lie_id = taa.lie_id
WHERE ani_id = '".$id."'
GROUP BY t_lieu_lie.lie_id;");
        return $query->result_array();
    }
    public function get_all_post(){
        $query = $this->db->query("SELECT NOM, Prenom, Photo, Pseudo, Libelle, Date_p
FROM invite_et_posts;");
        return $query->result_array();
    }


    public function get_lieux()
    {
        $query = $this->db->query("SELECT lie_nom , lie_description, GROUP_CONCAT('-', srv_type SEPARATOR '<br>') as services
FROM t_lieu_lie
LEFT OUTER JOIN t_service_srv tss on t_lieu_lie.lie_id = tss.lie_id
GROUP BY t_lieu_lie.lie_id;");
        return $query->result_array();
    }

    public function set_compte()
    {
        $this->load->helper('url');
        $id = addslashes($this->input->post('id'));
        $mdp = $this->input->post('mdp');
        $salt = "monselweb4event";
        $mdp = hash('sha256', $salt.$mdp);
        $req = "INSERT INTO t_compte_cpt VALUES ('" . $id . "','" . $mdp . "', 'I', 'A');";
        $query = $this->db->query($req);
        return ($query);
    }

    public function connect_compte($username, $password)
    {
        $query = $this->db->query("SELECT cpt_pseudo,cpt_mdp
        FROM t_compte_cpt
        WHERE cpt_pseudo='" . $username . "'
        AND cpt_mdp='" . $password . "';");
        if ($query->num_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function change_mdp($mdp_actuel, $mdp_nouveau)
    {

        $salt = "monselweb4event";
        $mdp = hash('sha256', $salt.$mdp_nouveau);
        $query = $this->db->query("UPDATE t_compte_cpt
SET cpt_mdp = '" . $mdp . "' 
WHERE cpt_mdp = '" . $mdp_actuel . "'");
        if ($query) {
            return true;
        } else {
            return false;
        }
    }

    public function get_user_status($username)
    {
        $query = $this->db->query("SELECT cpt_statut
        FROM t_compte_cpt
        WHERE cpt_pseudo='" . $username . "';");
        return $query->row();
    }

    public function get_admin_info($username)
    {
        $query = $this->db->query("SELECT org_nom as nom, org_prenom as prenom
FROM t_organisateur_org
where cpt_pseudo = '" . $username . "';");
        return $query->row();
    }

    public function get_invite_info($username)
    {
        $query = $this->db->query("SELECT inv_nom as nom, inv_prenom as prenom, inv_discipline as discipline, inv_biographie as biographie
FROM t_invite_inv
where cpt_pseudo = '" . $username . "';");
        return $query->row();
    }

    public function get_passport_post($username){
        $query = $this->db->query("SELECT
       inv_nom              as nom,
       inv_prenom           as prenom,
       t_passeport_pas.pas_id               as pass,
       pst_libelle          as texte_post,
       pst_date             as date_post,
       cpt_pseudo           as pseudo_inv
FROM t_invite_inv
         LEFT JOIN t_passeport_pas USING (inv_id)
         LEFT join t_post_pst tpp on t_passeport_pas.pas_id = tpp.pas_id
WHERE cpt_pseudo = '" .$username. "';");
        return $query->result_array();
    }
}